<?php
declare(strict_types=1);
/* DANGEROUS TEST DATABASE MUTATION — NEVER RUN ON HAKISEND PRODUCTION. */
if (getenv('R3_SANDBOX_ACK') !== 'ISOLATED_TEST_DATABASE_ONLY' ||
    getenv('R3_DB_NAME') !== 'r3_test' ||
    getenv('R3_DB_HOST') !== '127.0.0.1') {
    fwrite(STDERR,"RESULT=REFUSE_UNVERIFIED_ISOLATED_MYSQL_TEST_DATABASE\n");
    exit(7);
}
require __DIR__.'/vendor/autoload.php';
use Illuminate\Container\Container;
use Illuminate\Database\Capsule\Manager as Capsule;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Facade;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;
use App\Model\{Customer,User,MailList,Campaign,Email,Template};
use Hakisend\Sites\Models\Site;
use Hakisend\Publisheremail\Services\PrivateDraftCampaign;
$container=new Container;
Container::setInstance($container);
Facade::setFacadeApplication($container);
$capsule=new Capsule($container);
// Real Acelle runs Eloquent model events. Trigger the same creating hook in the test double.
$capsule->setEventDispatcher(new \Illuminate\Events\Dispatcher($container));
$capsule->addConnection([
'driver'=>'mysql','host'=>getenv('R3_DB_HOST')?:'127.0.0.1',
'port'=>(int)(getenv('R3_DB_PORT')?:'3306'),
'database'=>getenv('R3_DB_NAME')?:'r3_test',
'username'=>getenv('R3_DB_USER')?:'root',
'password'=>getenv('R3_DB_PASSWORD')?:'testpass',
'charset'=>'utf8mb4','collation'=>'utf8mb4_unicode_ci',
'prefix'=>'','strict'=>true,
]);
$capsule->setAsGlobal();$capsule->bootEloquent();
$container->instance('db',$capsule->getDatabaseManager());
$container->instance('db.schema',$capsule->getConnection()->getSchemaBuilder());
\Illuminate\Database\Eloquent\Model::unguard();
require __DIR__.'/models.php';
require __DIR__.'/native_publisher_services/MarkdownPreview.php';
require __DIR__.'/native_publisher_services/PrivateDraftCampaign.php';
$checks=0;
function checkit(bool $v,string $msg):void{
 global $checks;$checks++;if(!$v)throw new \RuntimeException('FAILED '.$msg);
 echo 'PASS='.$msg.PHP_EOL;
}
function blocked(callable $fn,string $error,string $label):void{
 try{$fn();}catch(\RuntimeException $e){
  checkit($e->getMessage()===$error,$label.'_'.$e->getMessage());return;
 }
 throw new \RuntimeException('EXPECTED_BLOCK '.$label);
}
function totals():array{
 return [DB::table('emails')->count(),DB::table('templates')->count(),
    DB::table('campaigns')->count(),DB::table('hakisend_email_draft_requests')->count(),
    DB::table('campaign_mail_lists')->count()];
}
$tables=['campaign_mail_lists','campaigns','emails','templates','sites',
 'mail_lists','users','customers','hakisend_email_site_audience_bindings',
 'hakisend_email_private_drafts','hakisend_email_draft_requests'];
foreach($tables as $table)Schema::dropIfExists($table);
try{
 Schema::create('customers',fn(Blueprint $t)=>$t->bigIncrements('id'));
 Schema::create('users',function(Blueprint $t){$t->bigIncrements('id');$t->unsignedBigInteger('customer_id');});
 Schema::create('sites',function(Blueprint $t){$t->bigIncrements('id');$t->unsignedBigInteger('customer_id');$t->string('status');});
 Schema::create('mail_lists',function(Blueprint $t){$t->bigIncrements('id');$t->unsignedBigInteger('customer_id');});
 Schema::create('templates',function(Blueprint $t){$t->bigIncrements('id');$t->unsignedBigInteger('customer_id')->nullable();$t->longText('content');$t->timestamps();});
 Schema::create('emails',function(Blueprint $t){
  $t->bigIncrements('id');$t->unsignedBigInteger('customer_id');$t->unsignedBigInteger('template_id')->nullable();
  $t->string('type')->nullable();$t->string('subject')->nullable();$t->string('preheader')->nullable();
  $t->string('from_email')->nullable();$t->string('from_name')->nullable();$t->string('reply_to')->nullable();
  $t->boolean('sign_dkim')->default(false);$t->boolean('track_open')->default(false);
  $t->boolean('track_click')->default(false);$t->timestamps();
 });
 Schema::create('campaigns',function(Blueprint $t){
  $t->bigIncrements('id');$t->string('uid',13)->unique();$t->unsignedBigInteger('customer_id');
  $t->unsignedBigInteger('email_id');$t->unsignedBigInteger('default_mail_list_id');
  $t->string('name');$t->string('status');$t->timestamp('run_at')->nullable();
  $t->timestamp('delivery_at')->nullable();$t->boolean('is_error')->default(false);
  $t->boolean('is_paused')->default(false);$t->timestamps();
 });
 Schema::create('campaign_mail_lists',function(Blueprint $t){
  $t->bigIncrements('id');$t->unsignedBigInteger('campaign_id');$t->unsignedBigInteger('list_id');
 });
 $migration=require __DIR__.'/actual_sites_private_email_migration.php';
 $migration->up();
 checkit(Schema::hasTable('hakisend_email_private_drafts'),'real_sites_private_drafts_table');
 checkit(Schema::hasTable('hakisend_email_draft_requests'),'real_sites_promotion_requests_table');
 checkit(Schema::hasTable('hakisend_email_site_audience_bindings'),'real_sites_list_bindings_table');
 $owner=Customer::create(['id'=>1]);$actor=User::create(['id'=>10,'customer_id'=>1]);
 $site=Site::create(['id'=>20,'customer_id'=>1,'status'=>Site::STATUS_ACTIVE]);
 $list=MailList::create(['id'=>30,'customer_id'=>1]);
 $draftUid='123e4567-e89b-42d3-a456-426614174000';
 $requestUid='123e4567-e89b-42d3-a456-426614174001';
 $otherUid='123e4567-e89b-42d3-a456-426614174002';
 DB::table('hakisend_email_site_audience_bindings')->insert([
  'customer_id'=>1,'site_id'=>20,'list_id'=>30,'approved_by_user_id'=>10,'enabled'=>1,
  'created_at'=>now(),'updated_at'=>now()
 ]);
 DB::table('hakisend_email_private_drafts')->insert([
  'uid'=>$draftUid,'request_uid'=>'123e4567-e89b-42d3-a456-426614174099',
  'customer_id'=>1,'site_id'=>20,'list_id'=>30,'created_by_user_id'=>10,
  'subject'=>'Synthetic Opt-in Newsletter','preheader'=>'Synthetic preview',
  'body_markdown'=>'# Hello test\nNo actual recipient.',
  'create_fingerprint'=>str_repeat('a',64),'status'=>'draft','revision'=>1,
  'created_at'=>now(),'updated_at'=>now()
 ]);
 $service=new PrivateDraftCampaign();
 checkit(PrivateDraftCampaign::tablesReady(),'service_reads_actual_migration');
 $run=fn($uid,$revision=1,$from='verified@example.test')=>
  $service->promote($owner,$actor,$draftUid,$uid,$revision,$from,'Test Sender','reply@example.test');
 blocked(fn()=> $run($requestUid,1,'not-verified@example.test'),'SENDER_NOT_VERIFIED','unverified_sender_blocks');
 checkit(totals()===[0,0,0,0,0],'sender_denial_has_zero_writes');
 blocked(fn()=> $run($requestUid,2),'DRAFT_REVISION_CONFLICT','wrong_revision_blocks');
 checkit(totals()===[0,0,0,0,0],'revision_denial_has_zero_writes');
 $actor->allowed=false;
 blocked(fn()=> $run($requestUid),'PROMOTION_INPUT_OR_PERMISSION_DENIED','missing_campaign_permission_blocks');
 $actor->allowed=true;
 checkit(totals()===[0,0,0,0,0],'permission_denial_has_zero_writes');
 DB::table('hakisend_email_site_audience_bindings')->where('site_id',20)->where('list_id',30)->update(['enabled'=>0]);
 blocked(fn()=> $run($requestUid),'AUDIENCE_REVOKED','site_list_binding_revoked_blocks');
 checkit(totals()===[0,0,0,0,0],'revoked_audience_has_zero_writes');
 DB::table('hakisend_email_site_audience_bindings')->where('site_id',20)->where('list_id',30)->update(['enabled'=>1]);
 Email::$simulateTemplateMismatch=true;
 blocked(fn()=> $run($requestUid),'EMAIL_TEMPLATE_NOT_VERIFIED','template_mismatch_blocks');
 checkit(totals()===[0,0,0,0,0],'failed_transaction_rolls_back_email_template_campaign');
 Email::$simulateTemplateMismatch=false;
 $campaignUid=$run($requestUid);
 checkit((bool)preg_match('/^[0-9a-f]{13}$/',$campaignUid),'real_service_native_campaign_uid');
 checkit(totals()===[1,1,1,1,1],'real_service_creates_one_campaign_and_receipt');
 $campaign=Campaign::query()->where('uid',$campaignUid)->first();
 checkit($campaign->status===Campaign::STATUS_NEW && $campaign->run_at===null,'real_service_draft_inert');
 checkit((int)$campaign->customer_id===1 && (int)$campaign->default_mail_list_id===30,'real_service_owner_and_list_binding');
 $createdEmail=Email::query()->whereKey($campaign->email_id)->first();
 checkit($createdEmail && $createdEmail->from_email==='verified@example.test','campaign_has_exact_sender_identity');
 checkit(str_contains((string)$createdEmail->template->content,'{{ unsubscribe_url }}'),'campaign_html_includes_native_unsubscribe_placeholder');
 checkit($run($requestUid)===$campaignUid,'same_request_is_idempotent');
 checkit(totals()===[1,1,1,1,1],'same_request_creates_no_duplicates');
 blocked(fn()=> $run($otherUid),'DRAFT_ALREADY_PROMOTED','new_request_same_draft_denied');
 checkit(totals()===[1,1,1,1,1],'second_request_creates_no_duplicates');
 $row=DB::table('hakisend_email_draft_requests')->where('customer_id',1)
  ->where('site_id',20)->where('private_draft_uid',$draftUid)->where('request_uid',$requestUid)
  ->where('status','completed')->first();
 checkit($row!==null&&$row->campaign_uid===$campaignUid,'receipt_exact_tenant_site_draft_request');
 checkit(!DB::table('hakisend_email_draft_requests')->where('customer_id',2)
   ->where('request_uid',$requestUid)->exists(),'cross_customer_receipt_absent');
 checkit(!DB::table('hakisend_email_draft_requests')->where('site_id',99)
   ->where('request_uid',$requestUid)->exists(),'cross_site_receipt_absent');
 checkit($campaign->mailLists()->count()===1,'single_native_list_attachment');
 echo "RESULT=R3_NATIVE_PROMOTION_REAL_SERVICE_MYSQL8_PASS CHECKS=$checks SMTP=NONE PROVIDER=NOT_TESTED\n";
}finally{
 foreach($tables as $table)Schema::dropIfExists($table);
}
