<?php
declare(strict_types=1);
namespace App\Model {
    use Illuminate\Database\Eloquent\Model;
    class Customer extends Model {
        protected $table='customers';public $timestamps=false;
    }
    class User extends Model {
        protected $table='users';public $timestamps=false;
        public bool $allowed=true;
        public function isActivated():bool {return true;}
        public function isProvisional():bool {return false;}
        public function hasPermission(string $key):bool{return $this->allowed&&$key==='campaign.full_access';}
        public function can($permission,$args=[]):bool{return $this->allowed&&$permission==='read';}
    }
    class MailList extends Model {
        protected $table='mail_lists';public $timestamps=false;
    }
    class Template extends Model {
        protected $table='templates';
    }
    class Email extends Model {
        public const TYPE_REGULAR='regular';
        protected $table='emails';
        public static bool $simulateTemplateMismatch=false;
        public function template(){return $this->belongsTo(Template::class,'template_id');}
        public function setCustomHtml($html,$subject):void{
            $template=new Template;
            $template->content=self::$simulateTemplateMismatch?'INCORRECT_HTML':$html;
            $template->save();
            $this->template_id=$template->id;$this->save();
        }
    }
    class Campaign extends Model {
        public const STATUS_NEW='new';
        protected $table='campaigns';
        protected static function booted():void{
            static::creating(function(Campaign $c):void{
                if(!$c->uid)$c->uid=substr(bin2hex(random_bytes(7)),0,13);
            });
        }
        public function mailLists(){return $this->belongsToMany(MailList::class,'campaign_mail_lists','campaign_id','list_id');}
        public function addListSegment(MailList $list):void{$this->mailLists()->attach($list->id);}
    }
}
namespace App\SendingServers\Identities {
    class IdentityCatalog {
        public function isEmailVerifiedForCustomer(\App\Model\Customer $owner,string $address):bool{
            return (int)$owner->id===1 && $address==='verified@example.test';
        }
    }
}
namespace Hakisend\Sites\Models {
    class Site extends \Illuminate\Database\Eloquent\Model {
        public const STATUS_ACTIVE='active';
        protected $table='sites';public $timestamps=false;
    }
}
namespace {
    if(!function_exists('app')) {
        function app(?string $class=null){
            $container=\Illuminate\Container\Container::getInstance();
            return $class ? $container->make($class) : $container;
        }
    }
    if(!function_exists('now')){function now(){return new \DateTimeImmutable('now',new \DateTimeZone('UTC'));}}
    if(!function_exists('abort_unless')){
        function abort_unless(bool $condition,int $code,string $message=''):void {
            if(!$condition)throw new \RuntimeException('HTTP_'.$code.' '.$message);
        }
    }
}
