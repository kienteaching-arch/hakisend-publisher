<?php
namespace Hakisend\Publisheremail\Services;

use DomainException;

/** Safe, intentionally narrow Markdown subset used for both preview and Campaign HTML. */
final class MarkdownPreview
{
    public static function render(string $raw): string
    {
        if (strlen($raw) > 200000 || str_contains($raw, "\0") || preg_match('//u', $raw) !== 1 ||
            str_contains($raw, '{{') || str_contains($raw, '{%')) {
            throw new DomainException('Unsafe or unsupported email Markdown');
        }
        $raw = str_replace(["\r\n", "\r"], "\n", $raw);
        $out = []; $paragraph = []; $list = false;
        $flush = static function () use (&$paragraph, &$out): void {
            if (!$paragraph) return;
            $out[] = '<p>' . self::inline(implode(' ', $paragraph)) . '</p>';
            $paragraph = [];
        };
        foreach (explode("\n", $raw) as $line) {
            $line = trim($line);
            if ($line === '') {
                $flush();
                if ($list) { $out[] = '</ul>'; $list = false; }
                continue;
            }
            if (preg_match('/^(#{1,4})[ \t]+(.+)$/u', $line, $m)) {
                $flush();
                if ($list) { $out[] = '</ul>'; $list = false; }
                $n = strlen($m[1]); $out[] = "<h{$n}>".self::inline($m[2])."</h{$n}>";
            } elseif (preg_match('/^[-*][ \t]+(.+)$/u', $line, $m)) {
                $flush();
                if (!$list) { $out[] = '<ul>'; $list = true; }
                $out[] = '<li>'.self::inline($m[1]).'</li>';
            } else {
                if ($list) { $out[] = '</ul>'; $list = false; }
                $paragraph[] = $line;
            }
        }
        $flush();
        if ($list) $out[] = '</ul>';
        $html = implode("\n", $out);
        if (strlen($html) > 500000 || trim($html) === '') throw new DomainException('Empty/oversize email');
        return $html;
    }
    private static function inline(string $value): string
    {
        $escaped = htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE | ENT_HTML5, 'UTF-8');
        $escaped = preg_replace_callback(
            '~\[([^\]\n]{1,200})\]\((https://[^\s\)\("<>]{1,2048})\)~iu',
            static function (array $m): string {
                $url = html_entity_decode($m[2], ENT_QUOTES | ENT_HTML5, 'UTF-8');
                $parts = parse_url($url);
                if (strlen($url) > 2048 || filter_var($url, FILTER_VALIDATE_URL) === false ||
                    !is_array($parts) || strtolower((string)($parts['scheme'] ?? '')) !== 'https' ||
                    isset($parts['user']) || isset($parts['pass'])) return $m[0];
                return '<a href="'.htmlspecialchars($url, ENT_QUOTES | ENT_HTML5, 'UTF-8').'">'.$m[1].'</a>';
            }, $escaped
        );
        $escaped = preg_replace('/\*\*([^*\n]+)\*\*/u', '<strong>$1</strong>', $escaped);
        return preg_replace('/(?<!\*)\*([^*\n]+)\*(?!\*)/u', '<em>$1</em>', $escaped);
    }
    public static function campaignHtml(string $markdown): string
    {
        return '<!doctype html><html><head><meta charset="utf-8"></head><body>' .
            '<div style="max-width:680px;margin:0 auto;font-family:Arial,sans-serif;line-height:1.6">' .
            self::render($markdown) .
            '<p style="margin-top:32px;border-top:1px solid #ddd;padding-top:15px">' .
            '<a href="{{ unsubscribe_url }}">Unsubscribe</a></p></div></body></html>';
    }
}
