<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
    public function up():void {
        if(!Schema::hasTable('hakisend_email_site_audience_bindings')) {
            Schema::create('hakisend_email_site_audience_bindings',function(Blueprint $t) {
                $t->bigIncrements('id');$t->unsignedBigInteger('customer_id');$t->unsignedBigInteger('site_id');
                $t->unsignedBigInteger('list_id');$t->unsignedBigInteger('approved_by_user_id');
                $t->boolean('enabled')->default(false);$t->timestamps();
                $t->unique(['site_id','list_id'],'hks_email_site_list_unique');
                $t->index(['customer_id','site_id','enabled'],'hks_email_bind_owner_idx');
            });
        }
        if(!Schema::hasTable('hakisend_email_private_drafts')) {
            Schema::create('hakisend_email_private_drafts',function(Blueprint $t) {
                $t->bigIncrements('id');$t->uuid('uid')->unique();$t->uuid('request_uid');
                $t->unsignedBigInteger('customer_id');$t->unsignedBigInteger('site_id');
                $t->unsignedBigInteger('list_id');$t->unsignedBigInteger('created_by_user_id');
                $t->string('subject',255);$t->string('preheader',255)->nullable();
                $t->mediumText('body_markdown');$t->char('create_fingerprint',64);
                $t->string('status',20)->default('draft');$t->unsignedInteger('revision')->default(1);
                $t->timestamps();
                $t->unique(['customer_id','request_uid'],'hks_email_draft_request_unique');
                $t->index(['customer_id','site_id','updated_at'],'hks_email_draft_owner_idx');
            });
        }
        // Reserved for later Acelle promotion: no side effects are wired to this table in M288B.
        if(!Schema::hasTable('hakisend_email_draft_requests')) {
            Schema::create('hakisend_email_draft_requests',function(Blueprint $t) {
                $t->bigIncrements('id');$t->unsignedBigInteger('customer_id');$t->unsignedBigInteger('site_id');
                $t->uuid('request_uid');$t->uuid('private_draft_uid');$t->string('campaign_uid',191)->nullable();
                $t->char('fingerprint',64);$t->string('status',20)->default('reserved');
                $t->timestamp('claimed_at')->nullable();$t->timestamp('completed_at')->nullable();$t->timestamps();
                $t->unique(['customer_id','request_uid'],'hks_email_promotion_unique');
            });
        }
    }
    // Never delete private customer content during an automatic rollback.
    public function down():void {}
};
