#!/usr/bin/env python3
"""Read-only source parity checks. No internet, app, DB, provider or secrets."""
from pathlib import Path
import hashlib, re, sys
root=Path(__file__).resolve().parent
checks=0

def check(ok,label):
    global checks
    checks+=1
    print(('PASS=' if ok else 'FAIL=')+label)
    if not ok:raise SystemExit(2)

def read(name): return (root / name).read_text()
def sha(name): return hashlib.sha256((root/name).read_bytes()).hexdigest()
check(sha('PrivateDraftCampaign.php')=='991b10713a1f6066684c6441aac0936be5848ccb1c1d0796bfc626da86ea255c','exact_publisher_0_6_9_private_draft_campaign_sha')
check(sha('actual_sites_private_email_migration.php')=='29b7556975e11731efb194154d5557225904ee6d70110e772124f42ce79cfedb','exact_sites_0_15_10_private_email_migration_sha')
p=read('PrivateDraftCampaign.php')
check('return DB::transaction(' in p and 'lockForUpdate()->first()' in p,'native_service_transaction_and_row_lock')
check("'DRAFT_ALREADY_PROMOTED'" in p and "'PROMOTION_REQUEST_CONFLICT'" in p,'no_duplicate_approval_guards_present')
check('IdentityCatalog::class' in p and 'isEmailVerifiedForCustomer' in p,'verified_sender_requires_runtime_identity_catalog')
check('Campaign::STATUS_NEW' in p and '$campaign->run_at = null;' in p,'native_campaign_created_new_without_schedule')
check('->addListSegment($list)' in p and '$campaign->mailLists()->count() !== 1' in p,'one_authorized_native_list')
check('MarkdownPreview::campaignHtml' in p,'native_email_uses_canonical_markdown_renderer')
check('DB::table(self::REQUESTS)->insert([' in p and "'status' => 'completed'" in p,'promotion_receipt_row_in_same_transaction')
check('R3_SANDBOX_ACK' in read('native_mysql_test.php') and "getenv('R3_DB_NAME') !== 'r3_test'" in read('native_mysql_test.php'),'destructive_db_test_guarded_to_isolated_database')
check('class IdentityCatalog' in read('models.php'),'native_model_stub_does_not_claim_production_identity')
check('RESULT=R3_NATIVE_PROMOTION_READ_ONLY_PROBE_V2_COMPLETE' in read('R3_NATIVE_PROMOTION_READONLY_PROBE_V2.php'),'runtime_probe_is_read_only_structural_report')
print('RESULT=R3_PROMOTION_SOURCE_PARITY_STATIC_PASS CHECKS='+str(checks)+' MYSQL=NOT_RUN')
