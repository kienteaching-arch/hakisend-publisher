<?php
declare(strict_types=1);
/*
 * R3 native promotion compatibility READ ONLY. Execute as hakisend-app in app root.
 * Does not inspect secret values, list recipient data, SMTP or email bodies.
 * No insert/update/delete, no artisan migrations, no outbound HTTP, no mail.
 */
$root = '/var/www/sites/hakisend.com/app';
if (!is_file($root.'/bootstrap/app.php') || !is_file($root.'/vendor/autoload.php')) {
    fwrite(STDERR, "RESULT=APP_NOT_FOUND\n"); exit(2);
}
require_once $root.'/vendor/autoload.php';
$app = require $root.'/bootstrap/app.php';
$app->make(\Illuminate\Contracts\Console\Kernel::class)->bootstrap();
$results=[];
$print=static function(string $key, bool $ok) use (&$results):void {
    $results[$key] = $ok;
    echo $key.'='.($ok?'YES':'NO')."\n";
};
$checkMethod=static function(string $class,string $method,string $label) use ($print):void {
    try {$print($label, class_exists($class) && method_exists($class,$method));}
    catch (\Throwable) {$print($label,false);}
};
$checkClass=static function(string $class,string $label) use ($print):void {
    try{$print($label,class_exists($class));}catch(\Throwable){$print($label,false);}
};
$checkClass('App\\Model\\Campaign','ACELLE_CAMPAIGN_MODEL');
$checkClass('App\\Model\\Email','ACELLE_EMAIL_MODEL');
$checkClass('App\\Model\\Template','ACELLE_TEMPLATE_MODEL');
$checkClass('App\\Model\\MailList','ACELLE_MAILLIST_MODEL');
$checkClass('Hakisend\\Sites\\Models\\Site','SITE_MODEL');
$checkClass('Hakisend\\Sites\\EmailDraft\\DraftAccess','SITES_DRAFT_ACCESS');
$checkClass('Hakisend\\Sites\\Http\\Middleware\\PublishingApiHardening','OAUTH_HARDENING');
$checkClass('Hakisend\\Sites\\Http\\Middleware\\PublishingApiAuthenticate','OAUTH_AUTHENTICATE');
$checkClass('Hakisend\\Sites\\Http\\Middleware\\PublishingApiScope','OAUTH_SCOPE');
$identity='App\\SendingServers\\Identities\\IdentityCatalog';
$checkClass($identity,'NATIVE_VERIFIED_SENDER_CLASS');
$checkMethod($identity,'isEmailVerifiedForCustomer','NATIVE_VERIFIED_SENDER_METHOD');
$checkMethod('App\\Model\\Email','setCustomHtml','NATIVE_SET_CUSTOM_HTML');
$checkMethod('App\\Model\\Campaign','addListSegment','NATIVE_CAMPAIGN_ADD_LIST');
$checkMethod('App\\Model\\Campaign','mailLists','NATIVE_CAMPAIGN_LISTS');
$checkMethod('App\\Model\\Campaign','isReadyToSend','NATIVE_CAMPAIGN_READINESS');
$checkMethod('App\\Model\\Campaign','validateLaunchPolicy','NATIVE_CAMPAIGN_LAUNCH_POLICY');
$checkMethod('App\\Model\\Campaign','countSubscribersToSend','NATIVE_RECIPIENT_COUNT');
$schema=\Illuminate\Support\Facades\Schema::class;
foreach([
  'hakisend_email_private_drafts'=>['uid','customer_id','site_id','list_id','subject','body_markdown','revision','status'],
  'hakisend_email_draft_requests'=>['customer_id','site_id','request_uid','private_draft_uid','campaign_uid','fingerprint','status','claimed_at','completed_at'],
  'hakisend_email_site_audience_bindings'=>['customer_id','site_id','list_id','enabled'],
  'hakisend_publisher_delivery_approvals'=>['customer_id','site_id','campaign_id','request_uid','status'],
  'campaigns'=>['id','uid','customer_id','email_id','default_mail_list_id','name','status','run_at'],
  'emails'=>['id','customer_id','subject','from_email','from_name','reply_to'],
] as $table=>$cols){
  try{
    $present=$schema::hasTable($table);
    $print('TABLE_'.strtoupper($table),$present);
    if($present){
      $missing=[];
      foreach($cols as $col)if(!$schema::hasColumn($table,$col))$missing[]=$col;
      $print('COLUMNS_'.strtoupper($table),count($missing)===0);
      if($missing)echo 'MISSING_COLUMNS_'.strtoupper($table).'='.implode(',',$missing)."\n";
    }
  }catch(\Throwable){$print('TABLE_'.strtoupper($table),false);}
}
try{
  $key='api/v1/hakisend/sites/{siteUid}/emails/drafts/{draftUid}/campaign-drafts';
  $post=false;$get=false;
  foreach(\Illuminate\Support\Facades\Route::getRoutes() as $route){
     $p=$route->uri();$verbs=$route->methods();
     if($p===$key && in_array('POST',$verbs,true))$post=true;
     if($p===$key.'/{requestUid}' && in_array('GET',$verbs,true))$get=true;
  }
  $print('R3_CAMPAIGN_PROMOTION_POST_MOUNTED',$post);
  $print('R3_CAMPAIGN_PROMOTION_GET_MOUNTED',$get);
}catch(\Throwable){echo "ROUTES=UNKNOWN\n";}
foreach([
 'HAKISEND_PUBLISHER_R3_PROMOTION_API_ENABLED'=>'r3_promotion_api_enabled',
 'HAKISEND_PUBLISHER_R3_READ_API_ENABLED'=>'r3_read_api_enabled',
 'HAKISEND_PUBLISHER_R3_WRITE_API_ENABLED'=>'r3_write_api_enabled',
] as $display=>$key){
  echo $display.'='.(config('hakisend-publisheremail.'.$key,false)===true?'ON':'OFF')."\n";
}
echo 'STRUCTURAL_CHECKS_YES='.count(array_filter($results)).' TOTAL='.count($results)."\n";
echo "RESULT=R3_NATIVE_PROMOTION_READ_ONLY_PROBE_V2_COMPLETE\n";
