<?php
namespace Hakisend\Publisheremail\Services;

use App\Model\{Campaign, Customer, Email, MailList, Template, User};
use Hakisend\Sites\Models\Site;
use Illuminate\Support\Facades\{DB, Gate, Schema};
use Illuminate\Support\Str;
use RuntimeException;

/**
 * Browser-triggered, unscheduled NEW Campaign creation. No sending, queuing, scheduling
 * or campaign launch in this service. Private draft content stays in Sites.
 */
final class PrivateDraftCampaign
{
    private const DRAFTS = 'hakisend_email_private_drafts';
    private const REQUESTS = 'hakisend_email_draft_requests';
    private const AUDIENCES = 'hakisend_email_site_audience_bindings';

    public static function tablesReady(): bool
    {
        foreach ([self::DRAFTS, self::REQUESTS, self::AUDIENCES] as $table) {
            if (!Schema::hasTable($table)) return false;
        }
        return true;
    }

    public static function ownedDraft(Customer $customer, User $actor, string $uid): object
    {
        abort_unless(Str::isUuid($uid) && self::tablesReady(), 404);
        $draft = DB::table(self::DRAFTS)->where('uid', $uid)
            ->where('customer_id', $customer->id)->where('status', 'draft')->first();
        abort_unless($draft, 404);
        $site = Site::query()->whereKey($draft->site_id)
            ->where('customer_id', $customer->id)->where('status', Site::STATUS_ACTIVE)->first();
        abort_unless($site && self::authorizedAudience($customer, $actor, $site, (int)$draft->list_id), 404);
        return $draft;
    }

    public static function authorizedAudience(Customer $owner, User $actor, Site $site, int $listId): bool
    {
        if ((int)$actor->customer_id !== (int)$owner->id ||
            (int)$site->customer_id !== (int)$owner->id ||
            $site->status !== Site::STATUS_ACTIVE || $listId < 1) return false;
        $list = MailList::query()->whereKey($listId)->where('customer_id', $owner->id)->first();
        return $list instanceof MailList && $actor->can('read', $list) &&
            DB::table(self::AUDIENCES)->where('customer_id', $owner->id)
                ->where('site_id', $site->id)->where('list_id', $listId)
                ->where('enabled', 1)->exists();
    }

    public function promote(Customer $owner, User $actor, string $draftUid,
        string $requestUid, int $revision, string $fromEmail, string $fromName, string $replyTo): string
    {
        if (!self::tablesReady() || !Str::isUuid($draftUid) || !Str::isUuid($requestUid) ||
            $revision < 1 || !filter_var($fromEmail, FILTER_VALIDATE_EMAIL) ||
            !filter_var($replyTo, FILTER_VALIDATE_EMAIL) ||
            trim($fromName) === '' || strlen($fromName) > 200 ||
            !$actor->isActivated() || $actor->isProvisional() ||
            (int)$actor->customer_id !== (int)$owner->id ||
            !$actor->hasPermission('campaign.full_access')) {
            throw new RuntimeException('PROMOTION_INPUT_OR_PERMISSION_DENIED');
        }
        // Verified sending identity must be resolved from Acelle server state.
        if (!class_exists(\App\SendingServers\Identities\IdentityCatalog::class) ||
            !app(\App\SendingServers\Identities\IdentityCatalog::class)
                ->isEmailVerifiedForCustomer($owner, $fromEmail)) {
            throw new RuntimeException('SENDER_NOT_VERIFIED');
        }
        $ownerId = (int)$owner->id;
        return DB::transaction(function () use ($owner, $actor, $draftUid, $requestUid,
            $revision, $fromEmail, $fromName, $replyTo, $ownerId): string {
            $draft = DB::table(self::DRAFTS)->where('uid', strtolower($draftUid))
                ->where('customer_id', $ownerId)->lockForUpdate()->first();
            if (!$draft || $draft->status !== 'draft' || (int)$draft->revision !== $revision ||
                !is_string($draft->body_markdown) || trim((string)$draft->subject) === '') {
                throw new RuntimeException('DRAFT_REVISION_CONFLICT');
            }
            $site = Site::query()->whereKey($draft->site_id)->where('customer_id', $ownerId)
                ->where('status', Site::STATUS_ACTIVE)->first();
            if (!$site || !self::authorizedAudience($owner, $actor, $site, (int)$draft->list_id)) {
                throw new RuntimeException('AUDIENCE_REVOKED');
            }
            $list = MailList::query()->whereKey($draft->list_id)->where('customer_id', $ownerId)->firstOrFail();
            $html = MarkdownPreview::campaignHtml((string)$draft->body_markdown);
            $fingerprint = hash('sha256', json_encode([
                $ownerId, (int)$site->id, strtolower($draftUid), $revision, (int)$list->id,
                (string)$draft->subject, $draft->preheader, hash('sha256', $draft->body_markdown),
                strtolower($fromEmail), $fromName, strtolower($replyTo),
            ], JSON_THROW_ON_ERROR | JSON_UNESCAPED_UNICODE));
            $prior = DB::table(self::REQUESTS)->where('customer_id', $ownerId)
                ->where('request_uid', strtolower($requestUid))->lockForUpdate()->first();
            if ($prior) {
                if ((string)$prior->private_draft_uid !== strtolower($draftUid) ||
                    !hash_equals((string)$prior->fingerprint, $fingerprint) ||
                    (string)$prior->status !== 'completed' || !$prior->campaign_uid) {
                    throw new RuntimeException('PROMOTION_REQUEST_CONFLICT');
                }
                $existing = Campaign::query()->where('customer_id', $ownerId)
                    ->where('uid', $prior->campaign_uid)->first();
                if (!$existing || $existing->status !== Campaign::STATUS_NEW || $existing->run_at !== null) {
                    throw new RuntimeException('PROMOTION_REPLAY_UNSAFE');
                }
                return (string)$existing->uid;
            }
            if (DB::table(self::REQUESTS)->where('customer_id', $ownerId)
                ->where('site_id', $site->id)->where('private_draft_uid', strtolower($draftUid))->exists()) {
                throw new RuntimeException('DRAFT_ALREADY_PROMOTED');
            }
            // Keep native Campaign creation inert. Acelle's own sending engine handles
            // explicit Test Send separately, never from a model event here.
            $email = new Email();
            $email->customer_id = $ownerId;
            $email->type = Email::TYPE_REGULAR;
            $email->subject = (string)$draft->subject;
            $email->preheader = $draft->preheader;
            $email->from_email = $fromEmail;
            $email->from_name = $fromName;
            $email->reply_to = $replyTo;
            $email->sign_dkim = false;
            $email->track_open = false;
            $email->track_click = false;
            $email->save();
            $email->setCustomHtml($html, (string)$draft->subject);
            $email->refresh();
            if (!$email->template || (string)$email->template->content !== $html) {
                throw new RuntimeException('EMAIL_TEMPLATE_NOT_VERIFIED');
            }
            // Template schema is source-version-dependent. Never set attributes
            // for columns that are not present on this production schema.
            if (Schema::hasColumn($email->template->getTable(), 'customer_id')) {
                $template = $email->template;
                $template->customer_id = $ownerId;
                $template->save();
            }
            $campaign = new Campaign();
            $campaign->customer_id = $ownerId;
            $campaign->email_id = $email->id;
            $campaign->default_mail_list_id = $list->id;
            $campaign->name = (string)$draft->subject;
            $campaign->status = Campaign::STATUS_NEW;
            $campaign->run_at = null;
            $campaign->delivery_at = null;
            $campaign->is_error = false;
            $campaign->is_paused = false;
            $campaign->save();
            $campaign->addListSegment($list);
            $campaign->refresh();
            if ($campaign->status !== Campaign::STATUS_NEW || $campaign->run_at !== null ||
                (int)$campaign->customer_id !== $ownerId ||
                $campaign->mailLists()->count() !== 1) {
                throw new RuntimeException('CAMPAIGN_DRAFT_NOT_VERIFIED');
            }
            DB::table(self::REQUESTS)->insert([
                'customer_id' => $ownerId, 'site_id' => $site->id,
                'request_uid' => strtolower($requestUid),
                'private_draft_uid' => strtolower($draftUid),
                'campaign_uid' => (string)$campaign->uid,
                'fingerprint' => $fingerprint, 'status' => 'completed',
                'claimed_at' => now(), 'completed_at' => now(),
                'created_at' => now(), 'updated_at' => now(),
            ]);
            return (string)$campaign->uid;
        }, 3);
    }
}
