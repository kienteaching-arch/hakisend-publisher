#!/usr/bin/env bash
set -euo pipefail
if [[ "${GITHUB_ACTIONS:-}" != "true" || "${R3_DB_HOST:-}" != "127.0.0.1" || "${R3_DB_NAME:-}" != "r3_test" ]]; then
  echo 'REFUSED: disposable GitHub Actions database required.' >&2
  exit 7
fi
export R3_SANDBOX_ACK=ISOLATED_TEST_DATABASE_ONLY
composer update --no-interaction --no-audit --no-scripts --prefer-dist --no-progress
python3 verify_exact_source.py
mkdir -p native_publisher_services
cp PrivateDraftCampaign.php MarkdownPreview.php native_publisher_services/
php native_mysql_test.php
